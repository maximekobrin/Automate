# Automate
projet de Maxime Kobrin Anthime L'Herminée et Antonin Victorion 
Ce projet permet de lire différents automates et de faire plusieurs opérations sur elles comme afficher les automates, completer, déterminer, complementariser,stantardiser et minimiser
